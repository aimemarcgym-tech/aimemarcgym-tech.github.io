#!/bin/sh
# Relance l'aide si elle s'arrete sur une erreur ; code 0 : deja lancee ou arretee normalement.
mkdir -p "$HOME/.cache"
while true; do
  node /opt/ffg-aide/aide-musique.mjs >> "$HOME/.cache/ffg-aide.log" 2>&1 && exit 0
  sleep 5
done
